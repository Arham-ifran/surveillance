<div class="error notice is-dismissible">
	<p><?php HtmlWpf::echoEscapedHtml($this->errorMsg); ?></p>
</div>
